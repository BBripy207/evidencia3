CREATE DATABASE superheroes;
USE superheroes;

CREATE TABLE universes (
    id INT PRIMARY KEY,
    universe VARCHAR(50) NOT NULL,
    company VARCHAR(50) NOT NULL,
    age VARCHAR(50) NOT NULL
);

CREATE TABLE characters (
    id INT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    real_name VARCHAR(100) NOT NULL,
    gender VARCHAR(10) NOT NULL,
    id_universe INT,
    FOREIGN KEY (id_universe) REFERENCES universes(id)
);

-- Insert data into universes table
INSERT INTO universes (id, universe, company, age) VALUES
(1, 'U1', 'DC', 'silvery'),
(2, 'U2', 'DC', 'golden'),
(3, 'U3', 'DC', 'modern'),
(4, 'U4', 'Marvel', 'silvery'),
(5, 'U5', 'Marvel', 'modern');

INSERT INTO characters (id, name, real_name, gender, id_universe) VALUES
(1, 'Spider-Man', 'Peter Benjamin Parker', 'Male', 4),
(2, 'Hulk', 'Robert Bruce Banner', 'Male', 4),
(3, 'Captain America', 'Steven Rogers', 'Male', 4),
(4, 'Superman', 'Clark Kent', 'Male', 2),
(5, 'Batman', 'Bruce Wayne', 'Male', 1),
(6, 'Scarlet Spider', 'Ben Reilly', 'Male', 5),
(7, 'Wonder Woman', 'Diana Prince', 'Female', 1),
(8, 'Doomsday', 'Not Applicable', 'Male', 3),
(9, 'Scarlet Witch', 'Wanda Maximoff', 'Female', 5),
(10, 'Night Wing', 'Dick Grayson', 'Male', 3);
SELECT * FROM universes;
SELECT * FROM characters;
