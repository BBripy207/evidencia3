using Microsoft.AspNetCore.Mvc.RazorPages;
using Activity6.Models;
using System.Collections.Generic;

namespace Activity6.Pages
{
    public class IndexModel : PageModel
    {
        public List<Product> Products { get; set; }

        public void OnGet()
        {
            // Simular una lista de productos
            Products = new List<Product>
            {
                new Product { Id = 1, Name = "Product 1", Price = 10.99M },
                new Product { Id = 2, Name = "Product 2", Price = 20.99M }
            };
        }
    }
}
