﻿using Microsoft.EntityFrameworkCore;
using demoMVC.Models;

namespace proyectoNuevo.Data
{
    public class MySQLDbContext : DbContext
    {
        // Constructor que recibe las opciones de configuración del DbContext
        public MySQLDbContext(DbContextOptions<MySQLDbContext> options) : base(options) { }

        // DbSet para la tabla "items" en la base de datos
        public DbSet<Item> items { get; set; } = null!; // Inicializada con null! para evitar advertencias

        // Método para configurar el modelo de la base de datos
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
        }
    }
}