using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using demoMVC.Models;
using proyectoNuevo.Data;
using System.Collections.Generic;

namespace demoMVC.Controllers;

public class HomeController : Controller
{
    private readonly ILogger<HomeController> _logger;

    private readonly MySQLDbContext context;

    public HomeController(ILogger<HomeController> _context)
    {
        this.context = context;
    }

    public IActionResult Index()
    {
        return View();
    }

    public IActionResult Privacy()
    {
        return View();
    }

    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error()
    {
        return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
    }

    public IActionResult ItemMuestra1()
    {
        Item item = new Item
        {
            id = 1,
            Name = "ostia",
            type = "bebe",
            STR = 453,
            AGI = 5345,
            INTE = 1350,
            MND = 1535430,
            VIT = 134320
        };
        return View(item);
    }

    public IActionResult Veritems()
    {
        List<Item> arrItems = context.Item.ToList();
        return View(arrItems);
    }

    [HttpGet("Home/ItemEspecifico/{id}")]
    public IActionResult ItemEspecifico(int id)
    {

        Item[] arrItems =
   {
            new Item {id=1,Name="señor",type="popo",STR=10,AGI=10,INTE=10,MND=10,VIT=10},
            new Item {id=2,Name="mae mia tio ",type="osias jrutas",STR=10,AGI=10,INTE=10,MND=10,VIT=10},
            new Item {id=3,Name="mamahuevo",type="seññorio ",STR=10,AGI=10,INTE=10,MND=10,VIT=10}

        };
        Item? item = arrItems.FirstOrDefault(p => id == p.id);
        if (item == null) return NotFound("mm");
        return View("IemMuestra", item);

    }

    [HttpGet("Home/ELitem/{name}/{id}")]
    public IActionResult ELItem(int id, string name)
    {
        return Content($"el id es:{id} yield el nombre {name}");
    }

}
