using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace demoMVC.Views.Home
{
    public class ItemMuestraModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
