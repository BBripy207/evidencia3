﻿using System.ComponentModel.DataAnnotations; 

namespace demoMVC.Models
{
    public class Item
    {
            public int id { get; set; }
            [Required(ErrorMessage = " este campo es requerido")]
            [StringLength(8, ErrorMessage = "debe contener un maximo de 8 caracteristicas")]
            public string Name { get; set; }
            public string type { get; set; }
            [Range(-100, 100, ErrorMessage = "el precio debe estar entre -100 y 100")]
            public int STR { get; set; }
            [Range(-100, 100, ErrorMessage = "el precio debe estar entre -100 y 100")]
            public int AGI { get; set; }
            [Range(-100, 100, ErrorMessage = "el precio debe estar entre -100 y 100")]
            public int INTE { get; set; }
            [Range(-100, 100, ErrorMessage = "el precio debe estar entre -100 y 100")]
            public int MND { get; set; }
            [Range(-100, 100, ErrorMessage = "el precio debe estar entre -100 y 100")]
            public int VIT { get; set; }
        }
    }


