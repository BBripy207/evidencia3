using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using menus.Models;
using System.Text.Json;


namespace menus.Controllers;

public class HomeController : Controller
{
    private readonly HttpClient httpClient;

    public HomeController(HttpClient httpClient)
    {
        this.httpClient = httpClient;
    }
    [HttpGet("Home/GetJoke")]
    public async Task<IActionResult> GetJoke()
    {
        string url = "https://v2.jokeapi.dev/joke/Any?safe-mode";
        HttpResponseMessage response = await httpClient.GetAsync(url);

        if (!response.IsSuccessStatusCode)
        {
            return NotFound();
        }

        string json = await response.Content.ReadAsStringAsync();
        JsonDocument doc = JsonDocument.Parse(json);

        string jokeText;
        if (doc.RootElement.GetProperty("type").GetString() == "single")
        {
            jokeText = doc.RootElement.GetProperty("joke").GetString();
        }
        else
        {
            var setup = doc.RootElement.GetProperty("setup").GetString();
            var delivery = doc.RootElement.GetProperty("delivery").GetString();
            jokeText = $"{setup} ... {delivery}";
        }

        ViewBag.Joke = jokeText;
        return View();
    }


    [HttpGet("Home/GetPokemon/{name}")]
    public async Task<IActionResult> GetPokemon(string name)
    {
        String url = $"https://pokeapi.co/api/v2/pokemon/{name}";
        HttpResponseMessage response =
             await httpClient.GetAsync(url);
        if (!response.IsSuccessStatusCode)
        {
            return NotFound();
        }
        String json = await response
                           .Content
                           .ReadAsStringAsync();
        JsonDocument doc = JsonDocument
                          .Parse(json);
        Pokemon pokemon = new Pokemon
        {
            Name = doc.RootElement.GetProperty("name").GetString(),
            ImageUrl = doc
                   .RootElement
                   .GetProperty("sprites")
                   .GetProperty("front_default")
                   .GetString(),
            Types = doc.RootElement.GetProperty("types")
           .EnumerateArray()
           .Select(t => t.GetProperty("type")
                       .GetProperty("name")
                       .GetString())
                  .ToList(),
            Abilities = doc.RootElement.GetProperty("abilities")
                .EnumerateArray()
                .Select(a => a.GetProperty("ability")
                              .GetProperty("name")
                              .GetString())
                 .ToList(),
            Weight = doc.RootElement.GetProperty("weight").GetInt32(),
        };

        return View(pokemon);
    }

    public async Task<IActionResult> Index()
    {
        string url = "https://v2.jokeapi.dev/joke/Any?safe-mode";
        HttpResponseMessage response = await httpClient.GetAsync(url);

        if (response.IsSuccessStatusCode)
        {
            string json = await response.Content.ReadAsStringAsync();
            JsonDocument doc = JsonDocument.Parse(json);

            string jokeText;
            if (doc.RootElement.GetProperty("type").GetString() == "single")
            {
                jokeText = doc.RootElement.GetProperty("joke").GetString();
            }
            else
            {
                var setup = doc.RootElement.GetProperty("setup").GetString();
                var delivery = doc.RootElement.GetProperty("delivery").GetString();
                jokeText = $"{setup} ... {delivery}";
            }

            ViewBag.Joke = jokeText;
        }
        else
        {
            ViewBag.Joke = "No joke found at the moment. Try again later!";
        }

        return View();
    }
    public IActionResult Privacy()
    {
        return View();
    }

    public IActionResult Photos()
    {
        return View();
    }

    public IActionResult Contact()
    {
        return View();
    }

    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error()
    {
        return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
    }
}
