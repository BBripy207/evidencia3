﻿namespace menus.Models
{
    public class Joke
    {
        public string Category { get; set; }
        public string Type { get; set; } 
        public string Language { get; set; }
        public string Content { get; set; }
        public string Setup { get; set; }
        public string Delivery { get; set; }
    }
}
